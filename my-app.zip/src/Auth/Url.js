//  const BaseUrl = "https://ems.pertrade.co.in";
   const BaseUrl = "http://localhost:5050";

export { BaseUrl };

